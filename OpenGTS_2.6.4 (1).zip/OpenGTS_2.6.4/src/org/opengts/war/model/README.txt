-----------------------------------------------------------------------------------
Project: OpenGTS - Open GPS Tracking System
URL    : http://www.opengts.org
File   : src/org/opengts/war/track/model/README.txt
-----------------------------------------------------------------------------------

Note:
The source modules in this directory might not be used in this release.
They are included here for possible use in a future version.
