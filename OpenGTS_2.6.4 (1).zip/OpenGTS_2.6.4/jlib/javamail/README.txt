-------------------------------------------------------------------------------
Project: OpenGTS - Open GPS Tracking System
URL    : http://www.opengts.org
File   : README.txt
-------------------------------------------------------------------------------

The JavaMail support included in this release is Copyright Sun Microsystems, Inc,
and is distributed in accordance with the terms specified by Sun Microsystems, Inc,
in the accompanying documentation.

-------------------------------------------------------------------------------

Description: JavaMail SMTP mail support
URL        : http://java.sun.com/products/javamail/downloads/index.html
Jar        : mail.jar

Jar should be copied to the following directories:
    $JAVA_HOME/jre/lib/ext/
    $JAVA_HOME/lib/ext/

