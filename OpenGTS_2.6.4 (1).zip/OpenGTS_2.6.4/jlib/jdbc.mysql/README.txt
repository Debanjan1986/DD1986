-------------------------------------------------------------------------------
Project: OpenGTS - Open GPS Tracking System
URL    : http://www.opengts.org
File   : jlib/jdbc.mysql/README.txt
-------------------------------------------------------------------------------

The MySQL JDBC driver (mysql-connector-java-5.1.10-bin.jar) may be copied to this
directory if it is not possible to copy these jars to the $JAVA_HOME directory.

-------------------------------------------------------------------------------

Description: Connector/J JDBC mysql driver
URL        : http://www.mysql.org
Jar        : mysql-connector-java-5.1.10-bin.jar

Jar should be copied to the following directories:
    $JAVA_HOME/jre/lib/ext/
    $JAVA_HOME/lib/ext/

