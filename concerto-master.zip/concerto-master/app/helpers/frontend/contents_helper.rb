module Frontend::ContentsHelper
end
