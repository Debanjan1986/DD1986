def system_has_mysql?
  true
end

def system_has_postgres?
  true
end
