require 'test_helper'

class ConcertoConfigHelperTest < ActionView::TestCase
end
