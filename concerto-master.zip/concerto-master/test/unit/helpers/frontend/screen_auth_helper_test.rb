require 'test_helper'

class Frontend::ScreenAuthHelperTest < ActionView::TestCase
end
