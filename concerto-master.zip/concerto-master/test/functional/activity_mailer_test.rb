require 'test_helper'

class ActivityMailerTest < ActionMailer::TestCase

end
